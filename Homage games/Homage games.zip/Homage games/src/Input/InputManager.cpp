
//#include "InputManager.h"
//#include "../Library/InputKeyPad/JoypadXInput.h"
//#include "../Library/InputKeyPad/KeyInput.h"
//#include "../Status/Library/Screen.h"
//#include <math.h>
//
//std::vector<int>InputManager::m_keyButton;
//std::vector<int>InputManager::m_joyButton;
//
////---------------------------------
////             ������
////---------------------------------
//void InputManager::Init()
//{
//	InputKey::Init();
//	InputPadX::Init();
//	//�����ݒ�
//	//�L�[�{�[�h
//	m_keyButton.push_back(KEY_INPUT_RETURN);	//����
//	m_keyButton.push_back(KEY_INPUT_TAB);		//�|�[�Y
//	m_keyButton.push_back(KEY_INPUT_TAB);		//�߂�	
//	m_keyButton.push_back(KEY_INPUT_SPACE);		//�W�����v
//	m_keyButton.push_back(KEY_INPUT_LSHIFT);	//�_�b�V��(�ړ��L�[(�{�^��)�Ɠ�������)
//	m_keyButton.push_back(KEY_INPUT_1);			//�A�C�e���P
//	m_keyButton.push_back(KEY_INPUT_2);			//�A�C�e���Q
//	m_keyButton.push_back(KEY_INPUT_3);			//�A�C�e���R
//	m_keyButton.push_back(KEY_INPUT_4);			//���ʃA�C�e��
//	m_keyButton.push_back(KEY_INPUT_F);			//�U��
//	m_keyButton.push_back(KEY_INPUT_SPACE);		//�㏸
//	m_keyButton.push_back(KEY_INPUT_LCONTROL);	//�~��
//	m_keyButton.push_back(KEY_INPUT_W);			//��ړ�
//	m_keyButton.push_back(KEY_INPUT_S);			//���ړ�
//	m_keyButton.push_back(KEY_INPUT_A);			//���ړ�
//	m_keyButton.push_back(KEY_INPUT_D);			//�E�ړ�
//	m_keyButton.push_back(KEY_INPUT_R);			//�_��
//	//�}�E�X
//	m_keyButton.push_back(-1);					//�U��
//	m_keyButton.push_back(-2);					//���_��ړ�
//	m_keyButton.push_back(-3);					//���_���ړ�
//	m_keyButton.push_back(-4);					//���_���ړ�
//	m_keyButton.push_back(-5);					//���_�E�ړ�
//	//�R���g���[���[
//	m_joyButton.push_back(XINPUT_BUTTON_B);					//����
//	m_joyButton.push_back(XINPUT_BUTTON_START);				//�|�[�Y
//	m_joyButton.push_back(XINPUT_BUTTON_START);				//�߂�
//	m_joyButton.push_back(XINPUT_BUTTON_Y);					//�W�����v
//	m_joyButton.push_back(XINPUT_BUTTON_A);					//�_�b�V��(�ړ��L�[(�{�^��)�Ɠ�������)
//	m_joyButton.push_back(XINPUT_BUTTON_DPAD_UP);			//�A�C�e���P
//	m_joyButton.push_back(XINPUT_BUTTON_DPAD_RIGHT);		//�A�C�e���Q
//	m_joyButton.push_back(XINPUT_BUTTON_DPAD_DOWN);			//�A�C�e���R
//	m_joyButton.push_back(XINPUT_BUTTON_DPAD_LEFT);			//���ʃA�C�e��
//	m_joyButton.push_back(XINPUT_BUTTON_X);					//�U��
//	m_joyButton.push_back(XINPUT_BUTTON_LEFT_THUMB);		//�㏸
//	m_joyButton.push_back(XINPUT_BUTTON_RIGHT_THUMB);		//�~��
//	m_joyButton.push_back(-1);								//��ړ�
//	m_joyButton.push_back(-2);								//���ړ�
//	m_joyButton.push_back(-3);								//���ړ�
//	m_joyButton.push_back(-4);								//�E�ړ�
//	m_joyButton.push_back(-5);								//�_��
//	m_joyButton.push_back(-6);								//�U��
//	m_joyButton.push_back(-7);								//���_��ړ�
//	m_joyButton.push_back(-8);								//���_���ړ�
//	m_joyButton.push_back(-9);								//���_���ړ�
//	m_joyButton.push_back(-10);								//���_�E�ړ�
//}
//
////---------------------------------
////            ���C������
////---------------------------------
//void InputManager::Update()
//{
//	SetMouseDispFlag(false);
//	InputKey::Update();
//	InputPadX::Update();
//	SetMousePoint(SCREEN_CENTER_X, SCREEN_CENTER_Y);
//}
//
////---------------------------------
//// �������������ꂽ��
////---------------------------------
//bool InputManager::IsPush(int key)
//{
//	//��ړ�
//	if (m_joyButton[key] == -1) {
//		if (InputPadX::IsLYSlope() == 1)return true;
//		else if (InputKey::IsPush(m_keyButton[key])) return true;
//		else return false;
//	}
//	//���ړ�
//	if (m_joyButton[key] == -2) {
//		if (InputPadX::IsLYSlope() == 2)return true;
//		else if (InputKey::IsPush(m_keyButton[key])) return true;
//		else return false;
//	}
//	//���ړ�
//	if (m_joyButton[key] == -3) {
//		if (InputPadX::IsLXSlope() == 2)return true;
//		else if (InputKey::IsPush(m_keyButton[key])) return true;
//		else return false;
//	}
//	//�E�ړ�
//	if (m_joyButton[key] == -4) {
//		if (InputPadX::IsLXSlope() == 1) return true;
//		else if (InputKey::IsPush(m_keyButton[key])) return true;
//		else return false;
//	}
//	//�_��
//	if (m_joyButton[key] == -5) {
//		if (InputPadX::IsPushLT()) return true;
//		else if (InputKey::IsPush(m_keyButton[key])) return true;
//		else return false;
//	}
//	//�U��
//	if (m_joyButton[key] == -6) {
//		if (InputPadX::IsPushRT()) return true;
//		else if (InputKey::IsLClick()) return true;
//		else return false;
//	}
//	else if (m_keyButton[key] == -1) {
//		if (InputKey::IsLClick()) return true;
//		else if (InputPadX::IsPushRT()) return true;
//		else return false;
//	}
//	//���_��ړ�
//	if (m_joyButton[key] == -7) {
//		if (InputPadX::IsRYSlope() == 1) return true;
//		else if (InputKey::IsYPos() == 1) return true;
//		else return false;
//	}
//	else if (m_keyButton[key] == -2) {
//		if (InputKey::IsYPos() == 1) return true;
//		else if (InputPadX::IsRYSlope() == 1) return true;
//		else return false;
//	}
//	//���_���ړ�
//	if (m_joyButton[key] == -8) {
//		if (InputPadX::IsRYSlope() == 2) return true;
//		else if (InputKey::IsYPos() == 2) return true;
//		else return false;
//	}
//	else if (m_keyButton[key] == -3) {
//		if (InputKey::IsYPos() == 2) return true;
//		else if (InputPadX::IsRYSlope() == 2) return true;
//		else return false;
//	}
//	//���_���ړ�
//	if (m_joyButton[key] == -9) {
//		if (InputPadX::IsRXSlope() == 2) return true;
//		else if (InputKey::IsXPos() == 2) return true;
//		else return false;
//	}
//	else if (m_keyButton[key] == -4) {
//		if (InputKey::IsXPos() == 2) return true;
//		else if (InputPadX::IsRXSlope() == 2) return true;
//		else return false;
//	}
//	//���_�E�ړ�
//	if (m_joyButton[key] == -10) {
//		if (InputPadX::IsRXSlope() == 1) return true;
//		else if (InputKey::IsXPos() == 1) return true;
//		else return false;
//	}
//	else if (m_keyButton[key] == -1) {
//		if (InputKey::IsXPos() == 1) return true;
//		else if (InputPadX::IsRXSlope() == 1) return true;
//		else return false;
//	}
//	return InputKey::IsPush(m_keyButton[key]) || InputPadX::IsPush(m_joyButton[key]);
//}
//
////---------------------------------
//// �����������Ă��邩
////---------------------------------
//bool InputManager::IsKeep(int key)
//{
//	//��ړ�
//	if (m_joyButton[key] == -1) {
//		if (InputPadX::IsLYSlope() == 1)return true;
//		else if (InputKey::IsKeep(m_keyButton[key])) return true;
//		else return false;
//	}
//	//���ړ�
//	if (m_joyButton[key] == -2) {
//		if (InputPadX::IsLYSlope() == 2)return true;
//		else if (InputKey::IsKeep(m_keyButton[key])) return true;
//		else return false;
//	}
//	//���ړ�
//	if (m_joyButton[key] == -3) {
//		if (InputPadX::IsLXSlope() == 2)return true;
//		else if (InputKey::IsKeep(m_keyButton[key])) return true;
//		else return false;
//	}
//	//�E�ړ�
//	if (m_joyButton[key] == -4) {
//		if (InputPadX::IsLXSlope() == 1) return true;
//		else if (InputKey::IsKeep(m_keyButton[key])) return true;
//		else return false;
//	}
//	//�_��
//	if (m_joyButton[key] == -5) {
//		if (InputPadX::IsPushLT()) return true;
//		else if (InputKey::IsKeep(m_keyButton[key])) return true;
//		else return false;
//	}
//	//�U��
//	if (m_joyButton[key] == -6) {
//		if (InputPadX::IsPushRT()) return true;
//		else if (InputKey::IsLClick()) return true;
//		else return false;
//	}
//	else if (m_keyButton[key] == -1) {
//		if (InputKey::IsLClick()) return true;
//		else if (InputPadX::IsPushRT()) return true;
//		else return false;
//	}
//	//���_��ړ�
//	if (m_joyButton[key] == -7) {
//		if (InputPadX::IsRYSlope() == 1) return true;
//		else if (InputKey::IsYPos() == 1) return true;
//		else return false;
//	}
//	else if (m_keyButton[key] == -2) {
//		if (InputKey::IsYPos() == 1) return true;
//		else if (InputPadX::IsRYSlope() == 1) return true;
//		else return false;
//	}
//	//���_���ړ�
//	if (m_joyButton[key] == -8) {
//		if (InputPadX::IsRYSlope() == 2) return true;
//		else if (InputKey::IsYPos() == 2) return true;
//		else return false;
//	}
//	else if (m_keyButton[key] == -3) {
//		if (InputKey::IsYPos() == 2) return true;
//		else if (InputPadX::IsRYSlope() == 2) return true;
//		else return false;
//	}
//	//���_���ړ�
//	if (m_joyButton[key] == -9) {
//		if (InputPadX::IsRXSlope() == 2) return true;
//		else if (InputKey::IsXPos() == 2) return true;
//		else return false;
//	}
//	else if (m_keyButton[key] == -4) {
//		if (InputKey::IsXPos() == 2) return true;
//		else if (InputPadX::IsRXSlope() == 2) return true;
//		else return false;
//	}
//	//���_�E�ړ�
//	if (m_joyButton[key] == -10) {
//		if (InputPadX::IsRXSlope() == 1) return true;
//		else if (InputKey::IsXPos() == 1) return true;
//		else return false;
//	}
//	else if (m_keyButton[key] == -1) {
//		if (InputKey::IsXPos() == 1) return true;
//		else if (InputPadX::IsRXSlope() == 1) return true;
//		else return false;
//	}
//	return InputKey::IsKeep(m_keyButton[key]) || InputPadX::IsKeep(m_joyButton[key]);
//}
//
////---------------------------------
//// �������������ꂽ��
////---------------------------------
//bool InputManager::IsRelease(int key)
//{
//	//��ړ�
//	if (m_joyButton[key] == -1) {
//		if (InputPadX::IsLYSlope() == 1)return true;
//		else if (InputKey::IsRelease(m_keyButton[key])) return true;
//		else return false;
//	}
//	//���ړ�
//	if (m_joyButton[key] == -2) {
//		if (InputPadX::IsLYSlope() == 2)return true;
//		else if (InputKey::IsRelease(m_keyButton[key])) return true;
//		else return false;
//	}
//	//���ړ�
//	if (m_joyButton[key] == -3) {
//		if (InputPadX::IsLXSlope() == 2)return true;
//		else if (InputKey::IsRelease(m_keyButton[key])) return true;
//		else return false;
//	}
//	//�E�ړ�
//	if (m_joyButton[key] == -4) {
//		if (InputPadX::IsLXSlope() == 1) return true;
//		else if (InputKey::IsRelease(m_keyButton[key])) return true;
//		else return false;
//	}
//	//�_��
//	if (m_joyButton[key] == -5) {
//		if (InputPadX::IsPushLT()) return true;
//		else if (InputKey::IsRelease(m_keyButton[key])) return true;
//		else return false;
//	}
//	//�U��
//	if (m_joyButton[key] == -6) {
//		if (InputPadX::IsPushRT()) return true;
//		else if (InputKey::IsLClick()) return true;
//		else return false;
//	}
//	else if (m_keyButton[key] == -1) {
//		if (InputKey::IsLClick()) return true;
//		else if (InputPadX::IsPushRT()) return true;
//		else return false;
//	}
//	//���_��ړ�
//	if (m_joyButton[key] == -7) {
//		if (InputPadX::IsRYSlope() == 1) return true;
//		else if (InputKey::IsYPos() == 1) return true;
//		else return false;
//	}
//	else if (m_keyButton[key] == -2) {
//		if (InputKey::IsYPos() == 1) return true;
//		else if (InputPadX::IsRYSlope() == 1) return true;
//		else return false;
//	}
//	//���_���ړ�
//	if (m_joyButton[key] == -8) {
//		if (InputPadX::IsRYSlope() == 2) return true;
//		else if (InputKey::IsYPos() == 2) return true;
//		else return false;
//	}
//	else if (m_keyButton[key] == -3) {
//		if (InputKey::IsYPos() == 2) return true;
//		else if (InputPadX::IsRYSlope() == 2) return true;
//		else return false;
//	}
//	//���_���ړ�
//	if (m_joyButton[key] == -9) {
//		if (InputPadX::IsRXSlope() == 2) return true;
//		else if (InputKey::IsXPos() == 2) return true;
//		else return false;
//	}
//	else if (m_keyButton[key] == -4) {
//		if (InputKey::IsXPos() == 2) return true;
//		else if (InputPadX::IsRXSlope() == 2) return true;
//		else return false;
//	}
//	//���_�E�ړ�
//	if (m_joyButton[key] == -10) {
//		if (InputPadX::IsRXSlope() == 1) return true;
//		else if (InputKey::IsXPos() == 1) return true;
//		else return false;
//	}
//	else if (m_keyButton[key] == -1) {
//		if (InputKey::IsXPos() == 1) return true;
//		else if (InputPadX::IsRXSlope() == 1) return true;
//		else return false;
//	}
//	return InputKey::IsRelease(m_keyButton[key]) || InputPadX::IsRelease(m_joyButton[key]);
//}
//
////---------------------------------
//// �P���ɉ�����Ă��邩
////---------------------------------
//bool InputManager::IsDown(int key)
//{
//	//��ړ�
//	if (m_joyButton[key] == -1) {
//		if (InputPadX::IsLYSlope() == 1)return true;
//		else if (InputKey::IsDown(m_keyButton[key])) return true;
//		else return false;
//	}
//	//���ړ�
//	if (m_joyButton[key] == -2) {
//		if (InputPadX::IsLYSlope() == 2)return true;
//		else if (InputKey::IsDown(m_keyButton[key])) return true;
//		else return false;
//	}
//	//���ړ�
//	if (m_joyButton[key] == -3) {
//		if (InputPadX::IsLXSlope() == 2)return true;
//		else if (InputKey::IsDown(m_keyButton[key])) return true;
//		else return false;
//	}
//	//�E�ړ�
//	if (m_joyButton[key] == -4) {
//		if (InputPadX::IsLXSlope() == 1) return true;
//		else if (InputKey::IsDown(m_keyButton[key])) return true;
//		else return false;
//	}
//	//�_��
//	if (m_joyButton[key] == -5) {
//		if (InputPadX::IsPushLT()) return true;
//		else if (InputKey::IsDown(m_keyButton[key])) return true;
//		else return false;
//	}
//	//�U��
//	if (m_joyButton[key] == -6) {
//		if (InputPadX::IsPushRT()) return true;
//		else if (InputKey::IsLClick()) return true;
//		else return false;
//	}
//	else if (m_keyButton[key] == -1) {
//		if (InputKey::IsLClick()) return true;
//		else if (InputPadX::IsPushRT()) return true;
//		else return false;
//	}
//	//���_��ړ�
//	if (m_joyButton[key] == -7) {
//		if (InputPadX::IsRYSlope() == 1) return true;
//		else if (InputKey::IsYPos() == 1) return true;
//		else return false;
//	}
//	else if (m_keyButton[key] == -2) {
//		if (InputKey::IsYPos() == 1) return true;
//		else if (InputPadX::IsRYSlope() == 1) return true;
//		else return false;
//	}
//	//���_���ړ�
//	if (m_joyButton[key] == -8) {
//		if (InputPadX::IsRYSlope() == 2) return true;
//		else if (InputKey::IsYPos() == 2) return true;
//		else return false;
//	}
//	else if (m_keyButton[key] == -3) {
//		if (InputKey::IsYPos() == 2) return true;
//		else if (InputPadX::IsRYSlope() == 2) return true;
//		else return false;
//	}
//	//���_���ړ�
//	if (m_joyButton[key] == -9) {
//		if (InputPadX::IsRXSlope() == 2) return true;
//		else if (InputKey::IsXPos() == 2) return true;
//		else return false;
//	}
//	else if (m_keyButton[key] == -4) {
//		if (InputKey::IsXPos() == 2) return true;
//		else if (InputPadX::IsRXSlope() == 2) return true;
//		else return false;
//	}
//	//���_�E�ړ�
//	if (m_joyButton[key] == -10) {
//		if (InputPadX::IsRXSlope() == 1) return true;
//		else if (InputKey::IsXPos() == 1) return true;
//		else return false;
//	}
//	else if (m_keyButton[key] == -1) {
//		if (InputKey::IsXPos() == 1) return true;
//		else if (InputPadX::IsRXSlope() == 1) return true;
//		else return false;
//	}
//	return InputKey::IsDown(m_keyButton[key]) || InputPadX::IsDown(m_joyButton[key]);
//}
//
////---------------------------------
//// X���W���_�ړ�
////---------------------------------
//float InputManager::IsCameraRotX()
//{
//	XINPUT_STATE padX = InputPadX::GetJoyPad();
//	float m_mouseX = InputKey::GetMouseX() - SCREEN_CENTER_X;
//
//	if (padX.ThumbRX > 1000 || padX.ThumbRX < -1000)
//	{
//		if (padX.ThumbRX > 0) return DEG_TO_RAD(2.0f);
//		else return DEG_TO_RAD(-2.0f);
//	}
//	else if (m_mouseX != 0)
//	{
//		return m_mouseX * 0.001f;
//	}
//	else return 0;
//}
//
////---------------------------------
//// Y���W���_�ړ�
////---------------------------------
//float InputManager::IsCameraRotY()
//{
//	XINPUT_STATE padY = InputPadX::GetJoyPad();
//	float m_mouseY = InputKey::GetMouseY() - SCREEN_CENTER_Y;
//
//	if (padY.ThumbRY > 1000 || padY.ThumbRY < -1000)
//	{
//		if (padY.ThumbRY > 0) return DEG_TO_RAD(-1.0f);
//		else return DEG_TO_RAD(1.0f);
//	}
//	else if (m_mouseY != 0)
//	{
//		return m_mouseY * 0.001f;
//	}
//	else return 0;
//}
