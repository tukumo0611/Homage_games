
#pragma once
#include <DxLib.h>

namespace COLOR
{
	static const int RED = GetColor(255, 0, 0);
	static const int GREEN = GetColor(0, 255, 0);
	static const int BLUE = GetColor(0, 0, 255);
	static const int WHITE = GetColor(255, 255, 255);
	static const int BLACK = GetColor(0, 0, 0);
	static const int YELLOW = GetColor(255, 255, 0);
	static const int ORANGE = GetColor(255, 165, 0);
	static const int PINK = GetColor(255, 192, 203);
	static const int MAGENTA = GetColor(255, 0, 255);
	static const int PURPLE = GetColor(138, 43, 226);
	static const int LIME = GetColor(127, 255, 0);
	static const int AQUA = GetColor(0, 255, 255);
}