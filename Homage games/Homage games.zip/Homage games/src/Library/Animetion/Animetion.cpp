
#include "Animetion.h"

//----------------------------
//������
//----------------------------
void CAnim::Init()
{
	ZeroMemory(&m_animData, sizeof(m_animData));
	m_animData.iHndl = -1;
	m_animData.m_id = -1;
}

//----------------------------
//�A�j���X�V
//----------------------------
void CAnim::UpdateAnim(int hndl)
{
	if (m_animData.iHndl == -1)return;

	m_animData.m_frm += m_animData.m_spd;

	if (m_animData.m_frm >= m_animData.m_endFrm)
	{
		switch (m_animData.m_state)
		{
		case ANIMSTATE_NORMAL:
			DetachAnim(hndl);
			m_animData.m_endFrm = 0.f;
			m_animData.m_frm = 0.0f;
			m_animData.m_spd = 0.0f;
			return;
		case ANIMSTATE_LOOP:
			m_animData.m_frm = 0.0f;
			break;
		case ANIMSTATE_END:
			m_animData.m_frm = m_animData.m_endFrm;
			break;
		}
	}

	MV1SetAttachAnimTime(hndl, m_animData.iHndl, m_animData.m_frm);
}

//----------------------------
//�`�揈��
//----------------------------
void CAnim::RequestAnim(int hndl, int iAnimID, float animSpd)
{
	if (m_animData.m_id == iAnimID) return;

	if (m_animData.m_id != -1)
	{
		MV1DetachAnim(hndl, m_animData.iHndl);
	}
	m_animData.iHndl = MV1AttachAnim(hndl, iAnimID);
	m_animData.m_id = iAnimID;
	m_animData.m_frm = 0.0f;
	m_animData.m_spd = animSpd;
	m_animData.m_endFrm = MV1GetAnimTotalTime(hndl, iAnimID);

}

//----------------------------
//���[�v���N�G�X�g
//----------------------------
void CAnim::RequestLoop(int hndl, int id, float spd)
{
	RequestAnim(hndl, id, spd);
	m_animData.m_state = ANIMSTATE_LOOP;
}

//----------------------------
//�G���h���[�v���N�G�X�g
//----------------------------
void CAnim::RequestEndLoop(int hndl, int id, float spd)
{
	RequestAnim(hndl, id, spd);
	m_animData.m_state = ANIMSTATE_END;
}


void CAnim::DetachAnim(int hndl)
{
	if (m_animData.iHndl != 1)
	{
		MV1DetachAnim(hndl, m_animData.iHndl);
		m_animData.iHndl = -1;
	}
}
