
#include "Billboard3D.h"

//----------------------------
//������
//----------------------------
void CBill3D::BillInit(const char* hndl, float cx, float cy,
	float size, float angle, bool flag)
{
	b_hndl = LoadGraph(hndl);
	b_vPos.y = -10;
	b_cx = cx;
	b_cy = cy;
	b_size = size;
	b_angle = angle;
	b_flag = flag;
}

//----------------------------
//�X�V
//----------------------------
void CBill3D::BillUpdate(VECTOR pos)
{
	b_vPos = pos;
}

//----------------------------
//�`��
//----------------------------
void CBill3D::BillDraw(int posy)
{
	DrawBillboard3D(VGet(b_vPos.x, b_vPos.y + posy, b_vPos.z), b_cx, b_cy, b_size, b_angle, b_hndl, b_flag);
}

//----------------------------
//�j��
//----------------------------
void CBill3D::BillFin()
{
	DeleteGraph(b_hndl);
}
