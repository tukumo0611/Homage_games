
#include "MyMath.h"

//----------------
// �������v�Z����
//----------------
VECTOR MyMath::CalcSegment(VECTOR vec1, VECTOR vec2)
{
	VECTOR result;
	result.x = vec1.x - vec2.x;
	result.y = vec1.y - vec2.y;
	result.z = vec1.z - vec2.z;
	return result;
}

//--------------------
// �[���x�N�g�����擾  
//--------------------
VECTOR MyMath::GetZeroVec()
{
	return VGet(0.0f, 0.0f, 0.0f);
}

//--------
// ��Βl
//--------
float MyMath::Abs(float val)
{
	if (val < 0.0f) {
		return -val;
	}
	return val;
}
