
#include "Matrix.h"
#include <math.h>

//---------------------------------
//�P�ʍs��̎擾
//---------------------------------
MATRIX CMatrix::Getldentity()
{
	MATRIX result = { 0 };
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			if (i == j) {
				result.m[i][j] = 1;
			}
			else {
				result.m[i][j] = 0;
			}
		}
	}

	return result;
}

//---------------------------------
//���s�ړ��s��̎擾
//---------------------------------
MATRIX CMatrix::GetTranslate(float x, float y, float z)
{
	MATRIX result = Getldentity();
	result.m[0][3] = x;
	result.m[1][3] = y;
	result.m[2][3] = z;

	return result;
}

//---------------------------------
//���s�ړ��s��̎擾
//---------------------------------
MATRIX CMatrix::GetTranslate(VECTOR trans)
{
	MATRIX result = Getldentity();
	result.m[0][3] = trans.x;
	result.m[1][3] = trans.y;
	result.m[2][3] = trans.z;

	return result;
}


//---------------------------------
//�g�k�s��̎擾
//---------------------------------
MATRIX CMatrix::GetScale(float x, float y, float z)
{
	MATRIX result = Getldentity();
	result.m[0][0] = x;
	result.m[1][1] = y;
	result.m[2][2] = z;

	return result;
}

//---------------------------------
//X����]�s��̎擾
//---------------------------------
MATRIX CMatrix::GetPitch(float rot)
{
	MATRIX result = Getldentity();
	result.m[1][1] = cosf(rot);
	result.m[1][2] = -sinf(rot);
	result.m[2][1] = sinf(rot);
	result.m[2][2] = cosf(rot);

	return result;
}

//---------------------------------
//Y����]�s��̎擾
//---------------------------------
MATRIX CMatrix::GetYaw(float rot)
{
	MATRIX result = Getldentity();
	result.m[0][0] = cosf(rot);
	result.m[0][2] = sinf(rot);
	result.m[2][0] = -sinf(rot);
	result.m[2][2] = cosf(rot);

	return result;
}

//---------------------------------
//Z����]�s��̎擾
//---------------------------------
MATRIX CMatrix::GetRoll(float rot)
{
	MATRIX result = Getldentity();
	result.m[0][0] = cosf(rot);
	result.m[0][1] = -sinf(rot);
	result.m[1][0] = sinf(rot);
	result.m[1][1] = cosf(rot);

	return result;
}

//---------------------------------
//�s��̑����Z
//---------------------------------
MATRIX CMatrix::MatAdd(MATRIX matA, MATRIX matB)
{
	MATRIX result = { 0 };
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			result.m[i][j] = matA.m[i][j] + matB.m[i][j];
		}
	}

	return result;
}

//---------------------------------
//�s��̊|���Z
//---------------------------------
MATRIX CMatrix::MatMult(MATRIX matA, MATRIX matB)
{
	MATRIX result = { 0 };
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			for (int k = 0; k < 4; k++) {
				result.m[i][j] += (matA.m[i][k] * matB.m[k][j]);
			}
		}
	}

	return result;
}

//---------------------------------
//�s��̃X�J���[�{
//---------------------------------
MATRIX CMatrix::MatScale(MATRIX mat, float scale)
{
	MATRIX result = { 0 };
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			result.m[i][j] = mat.m[i][j] * scale;
		}
	}

	return result;
}

//---------------------------------
//�s��̓]�u
//---------------------------------
MATRIX CMatrix::MatTranspose(MATRIX mat)
{
	MATRIX result = { 0 };
	for (int y = 0; y < 4; y++) {
		for (int x = 0; x < 4; x++) {
			result.m[x][y] = mat.m[y][x];
		}
	}

	return result;
}
