
#include "Draw2D.h"

int Draw2D::d_iHndl;
int Draw2D::m_x, Draw2D::m_y;
double Draw2D::m_rate;
double Draw2D::m_angle;
bool Draw2D::m_flag;


//----------------------------
//������
//----------------------------
void Draw2D::Init(const char* hndl, bool flag)
{
	d_iHndl = LoadGraph(hndl);
	m_x = 0;
	m_y = 0;
	m_rate = 1.0;
	m_angle = 0.0;
	m_flag = flag;
}

//----------------------------
//�X�V
//----------------------------
void Draw2D::Update(int x, int y, double rate, double angle)
{
	m_x = x;
	m_y = y;
	m_rate = rate;
	m_angle = angle;
}

//----------------------------
//�`��
//----------------------------
void Draw2D::Draw()
{
	DrawRotaGraph(m_x, m_y, m_rate, m_angle, d_iHndl, m_flag);
}

//----------------------------
//�j��
//----------------------------
void Draw2D::Fin()
{
	DeleteGraph(d_iHndl);
}
