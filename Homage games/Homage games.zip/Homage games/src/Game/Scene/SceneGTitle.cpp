
#include "SceneGTitle.h"

static const char GRAPH_PATH[] = "Data/Title/00Title.png";

// �R���X�g���N�^
SceneGTitle::SceneGTitle()
{
	s_stateID = SceneStateID::INIT;
}

// ������
void SceneGTitle::Init()
{
	SceneBase::Init();
}

// �v�Z����
bool SceneGTitle::Loop()
{
	bool res = false;

	switch (s_stateID)
	{

	case SceneStateID::INIT:
	{
		Init();
		Load(GRAPH_PATH);
		s_stateID = SceneStateID::STEP;
	}
	break;

	case SceneStateID::STEP:
	{
		inputK.Update();
		inputpX.Update();
		m_soundManager.LoopPlay(m_soundManager.SOUNDID_BGM_TITLE, 0.7f);
		if (inputK.IsPush(KEY_INPUT_RETURN) || inputpX.IsPush(XINPUT_BUTTON_B))
		{
			m_soundManager.NormalPlay(m_soundManager.SOUNDID_SE_ENTER, 0.6f);
			s_stateID = SceneStateID::FIN;
		}
	}
	break;

	case SceneStateID::FIN:
	{
		Fin();
		m_soundManager.Stop(m_soundManager.SOUNDID_BGM_TITLE);
		s_stateID = SceneStateID::INIT;
		res = true;
	}
	break;

	}

	return res;
}
