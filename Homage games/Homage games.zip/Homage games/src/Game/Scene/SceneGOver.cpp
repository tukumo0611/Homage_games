
#include "SceneGOver.h"

static const char GRAPH_PATH[] = "Data/Title/02GameOver.png";

// �R���X�g���N�^
SceneGOver::SceneGOver()
{
	s_stateID = SceneStateID::INIT;
}

// ������
void SceneGOver::Init()
{
	SceneBase::Init();
}

// �v�Z����
bool SceneGOver::Loop()
{
	bool res = false;

	switch (s_stateID)
	{

	case SceneStateID::INIT:
	{
		Init();
		Load(GRAPH_PATH);
		s_stateID = SceneStateID::STEP;
	}
	break;

	case SceneStateID::STEP:
	{
		inputK.Update();
		inputpX.Update();
		if (inputK.IsPush(KEY_INPUT_RETURN) || inputpX.IsPush(XINPUT_BUTTON_B))
		{
			m_soundManager.NormalPlay(m_soundManager.SOUNDID_SE_ENTER, 0.6f);
			s_stateID = SceneStateID::FIN;
		}
	}
	break;

	case SceneStateID::FIN:
	{
		Fin();
		s_stateID = SceneStateID::INIT;
		res = true;
	}
	break;

	}

	return res;
}
