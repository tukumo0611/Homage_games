
#pragma once
#include <DxLib.h>
#include "SceneBase.h"
#include "../../Game/Object/Actor/Player/Player.h"
#include "../../Game/Object/Actor/Enemy/EnemyManager.h"
#include "../../Game/Object/Actor/ItemEnemy/ItemEnemyManager.h"
#include "../../Game/Object/Actor/Shot/ShotManager.h"
#include "../Object/Ground/Ground.h"
#include "../Object/Sky/Sky.h"
#include "../Camera/CameraManager.h"
#include "../Collision/CollisionManager.h"

// �Q�[���{�҂̊Ǘ�
class SceneGPlay : public SceneBase
{
	Player m_player;
	EnemyManager m_enemy;
	ItemEnemyManager m_ienemy;
	ShotManager m_shot;
	Ground m_ground;
	Sky m_sky;
	CameraManager m_camera;
	CCollisionManager m_collision;

public:

	enum class State
	{
		Player,
		Enemy,
		Turret,
		Attack,
		Shot,
		Pikmin,
		Tower,
		Gate,
	};

	State StateID;

	bool Clear;
	bool GameOver;

private:
	// ������
	void Init();

	// �Q�[���{��
	void Step();

public:
	// �R���X�g���N�^
	SceneGPlay();

	// �l�X�Ȍv�Z����
	int Loop();

	// �`�揈��
	void Draw();

	// �I������
	void Fin();
};
