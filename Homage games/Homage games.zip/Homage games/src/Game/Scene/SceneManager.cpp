
#include "SceneManager.h"

// �R���X�g���N�^
SceneManager::SceneManager()
{
	//�^�C�g��
	s_sceneID = SceneID::TITLE;
}

// �f�X�g���N�^
SceneManager::~SceneManager()
{
	Fin();
}

// ���C������
int SceneManager::Loop()
{

	int ret = 0;

	switch (s_sceneID)
	{
	case SceneID::TITLE:
	{
		if (m_title.Loop())
			s_sceneID = SceneID::PLAY;
	}
	break;

	case SceneID::PLAY:
	{
		if (m_play.Loop())
		{
			if (m_play.Clear)
				s_sceneID = SceneID::CLEAR;
			else if (m_play.GameOver)
				s_sceneID = SceneID::GAMEOVER;
		}
	}
	break;

	case SceneID::CLEAR:
	{
		if (m_clear.Loop())
			s_sceneID = SceneID::TITLE;
	}
	break;

	case SceneID::GAMEOVER:
	{
		if (m_gameover.Loop())
			s_sceneID = SceneID::TITLE;
	}
	break;

	}
	return ret;
}

// �`�揈��
void SceneManager::Draw()
{
	switch (s_sceneID)
	{

	case SceneID::TITLE:
	{
		m_title.Draw();
	}
	break;

	case SceneID::PLAY:
	{
		m_play.Draw();
	}
	break;

	case SceneID::CLEAR:
	{
		m_clear.Draw();
	}
	break;

	case SceneID::GAMEOVER:
	{
		m_gameover.Draw();
	}
	break;
	}
}

// �I������
void SceneManager::Fin()
{
	m_title.Fin();
	m_play.Fin();
	m_clear.Fin();
	m_gameover.Fin();
}
