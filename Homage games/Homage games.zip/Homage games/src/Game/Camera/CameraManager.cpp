
#include "CameraManager.h"
#include "CameraPlay.h"
#include "CameraDebug.h"
#include <math.h>

// �R���X�g���N�^
CameraManager::CameraManager()
{
	m_cameraID = tagCameraID::PLAY;
}

// ������
void CameraManager::Init()
{
	m_playerCam.Init();
	m_playerCam.SetNearFar(1.0f, 5000.0f);
	m_debugCam.Init();
	m_debugCam.SetNearFar(1.0f, 5000.0f);
}

// �J�����̃��C������
void CameraManager::Step(VECTOR focus, float rotY)
{
	switch (m_cameraID)
	{
	case tagCameraID::PLAY:
		m_playerCam.Step(focus, rotY);
		if (CheckHitKey(KEY_INPUT_C) != 0)
		{
			m_cameraID = tagCameraID::DEBUG;
		}
		break;

	case tagCameraID::DEBUG:
		m_debugCam.Step(focus);
		if (CheckHitKey(KEY_INPUT_V) != 0)
		{
			m_cameraID = tagCameraID::PLAY;
		}
		break;
	}
}

// �v�Z���ʂ��������m�肳����
void CameraManager::Update()
{
	switch (m_cameraID)
	{
	case tagCameraID::PLAY:
		m_playerCam.Update();
		break;
	case tagCameraID::DEBUG:
		m_debugCam.Update();
		break;
	}
}
