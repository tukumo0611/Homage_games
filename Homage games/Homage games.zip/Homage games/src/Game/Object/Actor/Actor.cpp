
#include "Actor.h"

// ������
void Actor::Init()
{
	ObjectBase::Init();
	vPos.y = BASE_HIGHT;
	vVelocity = ZERO_VECTOR;
	fSpeed = BASE_SPEED;
	fRadius = BASE_RADIUS;
	iHp = BASE_HP;
	iDamege = BASE_DAMEGE;
	bActive = false;
	HitCheck = false;
}

// ���f����\��
void Actor::Draw()
{
	if (bActive)
	{
		// �����蔻��
		VECTOR hitPos = vPos;
		ObjectBase::Draw();
		//DrawSphere3D(hitPos, fRadius, DRAW_DIVNUM, RED, BLACK, FALSE);
	}
}

void Actor::Gravity()
{
	if (vPos.y > BASE_HIGHT)
	{
		vPos.y -= Common::GRAVITY / 10;
	}
	else if (vPos.y < BASE_HIGHT)
	{
		vPos.y = BASE_HIGHT;
	}
}
