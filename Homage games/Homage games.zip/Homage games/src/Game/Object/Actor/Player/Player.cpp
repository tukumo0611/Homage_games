
#include "player.h"
#include <math.h>

using namespace PLAYER_DEFINE;

// �R���X�g���N�^a
Player::Player()
{
	Init();
}

// �f�X�g���N�^
Player::~Player()
{
	Fin();
}

// ������
void Player::Init()
{
	Actor::Init();
	iHp = P_HP;
	iDamege = P_DAMAGE;
	fSpeed = P_MOVE_SPEED;
	fRadius = P_RADIUS;
	Level = P_LEVEL_NOME;
	iBSSLevel = P_LEVEL_NOME;
	iDMGLevel = P_LEVEL_NOME;
	iBLTLevel = P_LEVEL_NOME;
}

// �f�[�^�����[�h
void Player::Load()
{
	if (iHndl == -1)
	{
		iHndl = MV1LoadModel(P_MODEL_PATH);
		SetScale(VGet(P_SCALE, P_SCALE, P_SCALE));
		bActive = true;
	}
}

// ���C���̎��s����
void Player::Step(ShotManager& mShot)
{

	//input.Update();
	key.Update();

	// �ړ�����
	Move();

	Shot(mShot);
}

// �ŐV�̃f�[�^�ɍX�V
void Player::Update()
{
	vPos.y = BASE_HIGHT;
	MV1SetPosition(iHndl, vPos);
	MV1SetRotationXYZ(iHndl, vRot);
	MV1SetScale(iHndl, vScale);
}

// �ǉ��`�揈��
void Player::Draw()
{
	Actor::Draw();

	// HP�\��
	DrawFormatString(10, 10, BLACK, "Level[%d]", Level);

	// �U���͕\��
	DrawFormatString(10, 30, BLACK, "HP[%d]", iHp);

	// ���ˊԊu�\��
	//DrawFormatString(10, 50, BLACK, "���ˊԊu[%d]", P_SHOT_SPD / iBSSLevel);

	// �e�ې��\��
	//DrawFormatString(10, 70, BLACK, "�e�ې�[%d]", iBLTLevel);

	// �e�ۍU���͕\��
	//DrawFormatString(10, 90, BLACK, "�e�ۍU����[%d]", iDamege * iDMGLevel);
}

// �I��
void Player::Fin()
{
	Actor::Fin();
	iHp = -1;
	iDamege = -1;
	fSpeed = -1.0f;
	fRadius = -1.0f;
	Level = -1;
	iBSSLevel = -1;
	iDMGLevel = -1;
	iBLTLevel = -1;
}

// ���x���A�b�v
void Player::LevelUP()
{
	int RandNum = 0;
	Level++;
	m_sound.NormalPlay(m_sound.SOUNDID_SE_P_POWERUP, 0.6f);

	if (iBLTLevel < 3) RandNum = GetRand(2);
	else RandNum = GetRand(1);

	switch (RandNum)
	{
	case 0:
		UPBSSLevel();
		break;

	case 1:
		UPDMGLevel();
		break;
	
	case 2:
		UPBMNLevel();
		break;
	}
}

// �ړ�����
void Player::Move()
{
	// �O��ړ�
	float speed = 0.0f;
	//if (input.IsKeep(input.INPUT_MOVE_UP))		speed -= fSpeed;
	//if (input.IsKeep(input.INPUT_MOVE_DOWN))	speed += fSpeed;
	//if (key.IsKeep(KEY_INPUT_W)) speed -= fSpeed;
	//if (key.IsKeep(KEY_INPUT_S)) speed += fSpeed;
	//vPos.x += sinf(vRot.y) * speed;
	//vPos.z += cosf(vRot.y) * speed;

	// ���E�ړ�
	speed = 0.0f;
	//if (inputpX.IsKeep(input.INPUT_MOVE_RIGHT))	speed -= fSpeed;
	//if (inputpX.IsKeep(input.INPUT_MOVE_LEFT))	speed += fSpeed;
	if (P_MAXX >= vPos.x && vPos.x >= -P_MAXX) {
		if (key.IsKeep(KEY_INPUT_D)) speed -= fSpeed;
		if (key.IsKeep(KEY_INPUT_A)) speed += fSpeed;
		vPos.x += sinf(vRot.y + DX_PI_F * 0.5f) * speed;
		vPos.z += cosf(vRot.y + DX_PI_F * 0.5f) * speed;
	}
	else if (vPos.x > 0.0f)
		vPos.x -= 0.1f;
	else
		vPos.x += 0.1f;
}

// �ˌ�
void Player::Shot(ShotManager& Shot)
{
	if (GetWaitingTime() <= 0) {
		Shot.SetShotDamege(iDamege * iDMGLevel);
		Shot.Request(vPos, vRot.y, iBLTLevel);
		SetWaitingTime(P_SHOT_SPD / iBSSLevel);
		m_sound.NormalPlay(m_sound.SOUNDID_SE_P_SHOT, 0.5f);
	}
	else
		CountWaitingTime();
}
