
#include "ShotManager.h"
#include <math.h>

// �R���X�g���N�^
ShotManager::ShotManager()
{

}

// �f�X�g���N�^
ShotManager::~ShotManager()
{
	Fin();
}

// ������
void ShotManager::Init()
{
	for (int i = 0; i < BULLET_MAX_NUM; i++)
	{
		m_Shot[i].Init();
	}
	fSpeed = B_SPEED;
	WaitingTime = -1;
}

// �f�[�^�����[�h
void ShotManager::Load()
{
	int hndl = MV1LoadModel(B_MODEL_PATH);
	for (int i = 0; i < BULLET_MAX_NUM; i++)
	{
		m_Shot[i].Load(hndl);
	}
	MV1DeleteModel(hndl);
}

// �f�[�^�̔j��
void ShotManager::Fin()
{
	for (int i = 0; i < BULLET_MAX_NUM; i++)
	{
		m_Shot[i].Fin();
	}
}

// ���C���̎��s����
void ShotManager::Step()
{
	for (int i = 0; i < BULLET_MAX_NUM; i++)
	{
		if (!m_Shot[i].GetActive()) continue;
		
		m_Shot[i].Step();
	}
}

// �ŐV�̃f�[�^�ɍX�V
void ShotManager::Update()
{
	for (int i = 0; i < BULLET_MAX_NUM; i++)
	{
		if (!m_Shot[i].GetActive()) continue;

		m_Shot[i].Update();
	}
}

// ���f���̕\��
void ShotManager::Draw()
{
	for (int i = 0; i < BULLET_MAX_NUM; i++)
	{
		if (!m_Shot[i].GetActive()) continue;

		m_Shot[i].Draw();
	}
}

// �e���Ăяo��
void ShotManager::Request(const VECTOR pos, const float PRotY, const int LEVEL)
{
	VECTOR Pos = pos;
	int SFlagNum = 0;
	int Level = LEVEL;
	bool SFlag = false;

	// ��ԕ���
	VECTOR Dir = ZERO_VECTOR;
	Dir.x = sinf(PRotY) * -GetShotSpeed();
	Dir.y = 0.0f;
	Dir.z = cosf(PRotY) * -GetShotSpeed();

	for (int i = 0; i < BULLET_MAX_NUM; i++)
	{
		if (m_Shot[i].GetActive()) continue;

		if (Level == 1)
		{
			Pos = pos;
			Pos.z -= B_SPACE;
			SFlag = m_Shot[i].Request(Pos, Dir);
			if (SFlag) SFlagNum++;
		}
		if (SFlagNum >= Level) break;

		for (int j = i + 1; j < BULLET_MAX_NUM; j++)
		{
			if (m_Shot[j].GetActive()) continue;

			if (Level == 2)
			{
				Pos = pos;
				Pos.x -= B_SPACE;
				Pos.z -= B_SPACE;
				SFlag = m_Shot[i].Request(Pos, Dir);
				if (SFlag) SFlagNum++;

				Pos = pos;
				Pos.x += B_SPACE;
				Pos.z -= B_SPACE;
				SFlag = m_Shot[j].Request(Pos, Dir);
				if (SFlag) SFlagNum++;
			}
			if (SFlagNum >= Level) break;

			for (int k = j + 1; k < BULLET_MAX_NUM; k++)
			{
				if (m_Shot[j].GetActive()) continue;

				if (Level == 3)
				{
					Pos = pos;
					Pos.x -= B_SPACE * 1.5f;
					Pos.z -= B_SPACE;
					SFlag = m_Shot[i].Request(Pos, Dir);
					if (SFlag) SFlagNum++;

					Pos = pos;
					Pos.z -= B_SPACE;
					SFlag = m_Shot[j].Request(Pos, Dir);
					if (SFlag) SFlagNum++;

					Pos = pos;
					Pos.x += B_SPACE * 1.5f;
					Pos.z -= B_SPACE;
					SFlag = m_Shot[k].Request(Pos, Dir);
					if (SFlag) SFlagNum++;
				}
				if (SFlagNum >= Level) break;
			}
		}
	}
}
