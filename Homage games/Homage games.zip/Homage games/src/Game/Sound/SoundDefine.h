
#pragma once

namespace SOUND_DEFINE
{
	constexpr char S_BGM_START[] = "Data/Sound/Bgm/Bgm_Start.mp3";

	constexpr char S_BGM_LOOP[] = "Data/Sound/Bgm/Bgm_Loop.mp3";

	constexpr char S_BGM_Title[] = "Data/Sound/Bgm/Clear.mp3";

	constexpr char S_BGM_Clear[] = "Data/Sound/Bgm/Title.mp3";

	constexpr char S_SE_P_DEATH[] = "Data/Sound/Se/P_Death.mp3";

	constexpr char S_SE_P_HIT[] = "Data/Sound/Se/P_Hit.mp3";
	
	constexpr char S_SE_P_POWERUP[] = "Data/Sound/Se/P_Powerup.mp3";
	
	constexpr char S_SE_P_SHOT[] = "Data/Sound/Se/P_Shot.mp3";
	
	constexpr char S_SE_E_DEATH[] = "Data/Sound/Se/E_Death.mp3";

	constexpr char S_SE_E_HIT[] = "Data/Sound/Se/E_Hit.mp3";

	constexpr char S_BGM_US[] = "Data/Sound/Bgm/Unwelcome_School.mp3";
}