#include "Sound.h"

int SoundManager::m_iHndl[SOUNDID_NUM];

//�R���X�g���N�^
SoundManager::SoundManager(void)
{
	Init();
}

//�f�X�g���N�^
SoundManager::~SoundManager(void)
{
	Fin();
}

//������
void SoundManager::Init(void)
{
	for (int i = 0; i < SOUNDID_NUM; i++)
	{
		m_iHndl[i] = -1;
	}
}

//�I������
void SoundManager::Fin(void)
{
	for (int i = 0; i < SOUNDID_NUM; i++)
	{
		if (m_iHndl[i] != -1)
		{
			(m_iHndl[i]);
			m_iHndl[i] = -1;
		}
	}
}

//�S�f�[�^�ǂݍ���
void SoundManager::LoadAllData()
{
	bool isRet = true;
	const char pFileName[SOUNDID_NUM][128] =
	{
		"Data/Sound/Bgm/Bgm_Start.mp3",
		"Data/Sound/Bgm/Bgm_Loop.mp3",
		"Data/Sound/Bgm/Claer.mp3",
		"Data/Sound/Bgm/Title.mp3",
		"Data/Sound/Se/P_Death.mp3",
		"Data/Sound/Se/P_Hit.mp3",
		"Data/Sound/Se/P_Powerup.mp3",
		"Data/Sound/Se/P_Shot.mp3",
		"Data/Sound/Se/E_Death.mp3",
		"Data/Sound/Se/E_Hit.mp3",
		"Data/Sound/Se/Cursor_Push.mp3",
		"Data/Sound/Se/Cursor_Move.mp3",
		"Data/Sound/Bgm/Unwelcome_School.mp3"
	};

	for (int i = 0; i < SOUNDID_NUM; i++)
	{
		m_iHndl[i] = LoadSoundMem(pFileName[i]);
	}
}

// �Đ��J�n���Ԑݒ�
void SoundManager::SetStartFrame(tagSoundID iID, int ms)
{
	//�w��ID�̎��g�����擾���Đݒ�
	int iFreq = GetFrequencySoundMem(m_iHndl[iID]) * ms / 1000;
	SetCurrentPositionSoundMem(iFreq, m_iHndl[iID]);
}

// �{�����[���ݒ�
void SoundManager::SetVolume(tagSoundID iID, float fVol)
{
	if (fVol < 0.f || fVol>1.f) return;
	ChangeVolumeSoundMem((int)(255.f * fVol), m_iHndl[iID]);
}

// �ʏ�Đ�
void SoundManager::NormalPlay(tagSoundID iID, float Volume)
{
	SetVolume(iID, Volume);
	Play(iID, DX_PLAYTYPE_BACK);
}

// ���[�v�Đ�
void SoundManager::LoopPlay(tagSoundID iID, float Volume)
{
	if (IsPlay(iID))
		SetVolume(iID, Volume);
	else Play(iID, DX_PLAYTYPE_LOOP);
}
